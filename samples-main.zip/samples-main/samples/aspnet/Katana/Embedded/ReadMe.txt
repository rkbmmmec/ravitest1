Embedded Sample
----------------------

Some OWIN servers can be run inside of your own process ("self-hosted").  This sample
shows how to start an OWIN application using the tools provided by the
Microsoft.Owin.Hosting nuget package.
